#include <iostream>
#include <chrono>
#include <ctime>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include <map>
#include <unordered_map>
#include <limits>
#include <stdio.h>
#include <stdlib.h>
#include <algorithm>
#include <random>
#include <cmath>
#include <omp.h>

using namespace std;
using namespace std::chrono;

typedef unsigned long long * state;
bool equals_h(unsigned long long * a, unsigned long long * b) {
   for (int i = 0; i < 2; i++) {
       if (a[i] != b[i])
           return false;
   }
   return true;
}
void next_h(unsigned long long * s) {
   unsigned long long aux[2];
   aux[0] = 0;
   aux[1] = 0;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 50) % 2 ) * -2 ) >= 0 ) << 0;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 3) % 2 ) * 2 ) >= 2 ) << 1;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 44) % 2 ) * -2 ) >= 0 ) << 2;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 63) % 2 ) * 2 + ( ( s[0] >> 2) % 2 ) * 2 ) >= 2 ) << 3;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 3) % 2 ) * 2 + ( ( s[0] >> 62) % 2 ) * 2 ) >= 2 ) << 4;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 20) % 2 ) * 2 + ( ( s[0] >> 44) % 2 ) * -2 + ( ( s[0] >> 16) % 2 ) * 6 ) >= 2 ) << 5;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 10) % 2 ) * 2 ) >= 2 ) << 6;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 7) % 2 ) * 2 ) >= 2 ) << 7;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 16) % 2 ) * 2 + ( ( s[0] >> 20) % 2 ) * 2 ) >= 2 ) << 8;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 20) % 2 ) * 2 ) >= 2 ) << 9;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 44) % 2 ) * -2 ) >= 0 ) << 10;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 20) % 2 ) * 2 ) >= 2 ) << 11;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 10) % 2 ) * 2 ) >= 2 ) << 12;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 20) % 2 ) * 2 ) >= 2 ) << 13;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 14) % 2 ) * 2 ) >= 2 ) << 14;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 15) % 2 ) * 2 ) >= 2 ) << 15;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 7) % 2 ) * 2 ) >= 2 ) << 16;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 5) % 2 ) * 2 ) >= 2 ) << 17;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 8) % 2 ) * 2 ) >= 2 ) << 18;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 9) % 2 ) * 2 + ( ( s[1] >> 5) % 2 ) * 2 ) >= 2 ) << 19;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 10) % 2 ) * 2 + ( ( s[0] >> 21) % 2 ) * -2 ) >= 2 ) << 20;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 13) % 2 ) * 2 + ( ( s[0] >> 17) % 2 ) * -2 + ( ( s[0] >> 19) % 2 ) * -2 ) >= 2 ) << 21;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 14) % 2 ) * 2 + ( ( s[1] >> 6) % 2 ) * 2 + ( ( s[0] >> 49) % 2 ) * 2 ) >= 2 ) << 22;
    aux[0] |= (unsigned long long) ( ( ( ( s[1] >> 1) % 2 ) * -2 + ( ( s[0] >> 52) % 2 ) * -2 + ( ( s[0] >> 47) % 2 ) * -2 ) >= 0 ) << 23;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 52) % 2 ) * -2 + ( ( s[0] >> 47) % 2 ) * -2 ) >= 0 ) << 24;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 52) % 2 ) * -2 + ( ( s[0] >> 47) % 2 ) * -2 ) >= 0 ) << 25;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 44) % 2 ) * 6 + ( ( s[0] >> 52) % 2 ) * 2 + ( ( s[0] >> 47) % 2 ) * 2 ) >= 8 ) << 26;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 52) % 2 ) * -2 ) >= 0 ) << 27;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 52) % 2 ) * -2 ) >= 0 ) << 28;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 62) % 2 ) * 2 + ( ( s[0] >> 3) % 2 ) * 2 ) >= 2 ) << 29;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 3) % 2 ) * 2 ) >= 2 ) << 30;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 3) % 2 ) * 2 ) >= 2 ) << 31;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 44) % 2 ) * -2 ) >= 0 ) << 32;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 42) % 2 ) * 2 + ( ( s[0] >> 44) % 2 ) * -2 ) >= 2 ) << 33;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 42) % 2 ) * 2 + ( ( s[0] >> 44) % 2 ) * -2 ) >= 2 ) << 34;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 62) % 2 ) * 2 + ( ( s[0] >> 3) % 2 ) * 2 ) >= 2 ) << 35;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 20) % 2 ) * 2 + ( ( s[0] >> 44) % 2 ) * -2 ) >= 2 ) << 36;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 46) % 2 ) * -2 + ( ( s[0] >> 45) % 2 ) * -2 ) >= 0 ) << 37;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 52) % 2 ) * -2 ) >= 0 ) << 38;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 52) % 2 ) * -2 ) >= 0 ) << 39;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 62) % 2 ) * 2 + ( ( s[0] >> 3) % 2 ) * 2 ) >= 2 ) << 40;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 20) % 2 ) * 2 ) >= 2 ) << 41;
    aux[0] |= (unsigned long long) ( ( ( ( s[1] >> 8) % 2 ) * 2 + ( ( s[0] >> 32) % 2 ) * 2 ) >= 2 ) << 42;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 34) % 2 ) * 2 ) >= 2 ) << 43;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 37) % 2 ) * 2 + ( ( s[0] >> 63) % 2 ) * -2 ) >= 2 ) << 44;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 38) % 2 ) * 2 ) >= 2 ) << 45;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 39) % 2 ) * 2 + ( ( s[0] >> 63) % 2 ) * -2 ) >= 2 ) << 46;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 41) % 2 ) * 6 + ( ( s[1] >> 0) % 2 ) * -2 + ( ( s[0] >> 53) % 2 ) * -2 + ( ( s[1] >> 3) % 2 ) * -6 + ( ( s[0] >> 54) % 2 ) * -6 ) >= 4 ) << 47;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 3) % 2 ) * 2 ) >= 2 ) << 48;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 49) % 2 ) * 2 ) >= 2 ) << 49;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 50) % 2 ) * 2 ) >= 2 ) << 50;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 51) % 2 ) * 2 ) >= 2 ) << 51;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 50) % 2 ) * 6 + ( ( s[0] >> 47) % 2 ) * 2 + ( ( s[1] >> 1) % 2 ) * 2 ) >= 8 ) << 52;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 51) % 2 ) * 2 + ( ( s[1] >> 6) % 2 ) * 2 ) >= 2 ) << 53;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 15) % 2 ) * 2 ) >= 2 ) << 54;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 3) % 2 ) * 2 ) >= 2 ) << 55;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 3) % 2 ) * 2 ) >= 2 ) << 56;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 57) % 2 ) * 2 ) >= 2 ) << 57;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 44) % 2 ) * -2 + ( ( s[0] >> 46) % 2 ) * -2 + ( ( s[0] >> 45) % 2 ) * -2 ) >= 0 ) << 58;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 59) % 2 ) * 2 ) >= 2 ) << 59;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 52) % 2 ) * -2 ) >= 0 ) << 60;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 44) % 2 ) * -2 + ( ( s[0] >> 45) % 2 ) * -2 ) >= 0 ) << 61;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 56) % 2 ) * 2 + ( ( s[0] >> 63) % 2 ) * 2 ) >= 2 ) << 62;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 57) % 2 ) * 2 + ( ( s[0] >> 22) % 2 ) * -6 + ( ( s[0] >> 59) % 2 ) * 2 ) >= 2 ) << 63;
    aux[1] |= (unsigned long long) ( ( ( ( s[0] >> 58) % 2 ) * 2 + ( ( s[1] >> 6) % 2 ) * 2 ) >= 2 ) << 0;
    aux[1] |= (unsigned long long) ( ( ( ( s[0] >> 60) % 2 ) * 2 + ( ( s[0] >> 54) % 2 ) * -2 + ( ( s[1] >> 3) % 2 ) * -2 ) >= 2 ) << 1;
    aux[1] |= (unsigned long long) ( ( ( ( s[1] >> 2) % 2 ) * 2 ) >= 2 ) << 2;
    aux[1] |= (unsigned long long) ( ( ( ( s[1] >> 2) % 2 ) * 2 ) >= 2 ) << 3;
    aux[1] |= (unsigned long long) ( ( ( ( s[1] >> 4) % 2 ) * 2 ) >= 2 ) << 4;
    aux[1] |= (unsigned long long) ( ( ( ( s[0] >> 18) % 2 ) * 2 + ( ( s[1] >> 4) % 2 ) * 2 ) >= 2 ) << 5;
    aux[1] |= (unsigned long long) ( ( ( ( s[1] >> 6) % 2 ) * 2 ) >= 2 ) << 6;
    aux[1] |= (unsigned long long) ( ( ( ( s[1] >> 7) % 2 ) * 2 ) >= 2 ) << 7;
    aux[1] |= (unsigned long long) ( ( ( ( s[0] >> 43) % 2 ) * 2 + ( ( s[1] >> 7) % 2 ) * 2 ) >= 2 ) << 8;
   s[0] = aux[0];
   s[1] = aux[1];
}

void network_simulation_h(unsigned long long * statef, unsigned long long SIMULATIONS){
   unsigned long long i;
   for(i = 0; i < SIMULATIONS; i++){
       unsigned long long state0[2], state1[2], aux[2];
       state0[0] = state1[0] = statef[i*2 + 0];
       state0[1] = state1[1] = statef[i*2 + 1];
       do {
           next_h(state0);
           next_h(state1);
           next_h(state1);
       } while(!equals_h(state0, state1));
       statef[i*2 + 0] = state1[0];
       statef[i*2 + 1] = state1[1];
   }
}
string to_string(unsigned long long * s){
   string result;
   stringstream stream;
   for(int i = 1; i >= 0; i--)
       stream << s[i];
   stream >> result;
   return result;
}
string to_string(vector<string> atractor){
   if(atractor.size() == 0) return "['']";
   string result = "[" + atractor[0];
   for (int i = 1; i < atractor.size(); i++)
       result += "," + atractor[i];
   result += "]";
   return result;
}
vector<string> getAtractor(unsigned long long * s) {
   unsigned long long s0[2], s1[2], aux[2];
   vector<string> atractor; atractor.push_back(to_string(s));
   for (int i = 0; i < 2; i++){
       s0[i] = s1[i] = s[i];
       aux[i] = 0;
   }
   while(true) {
       next_h(s0);
       if (!equals_h(s0,s1))
           atractor.push_back(to_string(s1));
       else
           break;
   }
   sort(atractor.begin(), atractor.end());
   return atractor;
}
vector<string> complete_atractors(unsigned long long * state_f, unsigned long long SIMULATIONS){
   vector<string> atractors;
   unordered_map<string, string> state_to_at;
   unordered_map<string, unsigned long> at_freq;
   for(unsigned long long i = 0; i < SIMULATIONS; i++) {
       unsigned long long st[2];
       for (size_t j = 0; j < 2; j++) {
           st[j] = state_f[i*2 + j];
       }
       string sst = to_string(st);
       if (state_to_at.count(sst) > 0) {
           at_freq[state_to_at[sst]]++;
       } else {
           vector<string> at = getAtractor(st);
           string sat = to_string(at);
           atractors.push_back(sat);
           for (int j = 0; j < at.size(); j++)
               state_to_at[at[j]] = sat;
           at_freq[sat]=1;
       }
   }
   return atractors;
}
void output_atractors(const vector<string> &atractors) {
   ofstream atractorsFile;
   atractorsFile.open("atractors.json");
   atractorsFile << "{\n";
   atractorsFile << "\"nodes\" : [";
   atractorsFile << "\"4ORFs\",";
   atractorsFile << "\"ACS1\",";
   atractorsFile << "\"CAT8\",";
   atractorsFile << "\"Cat8p\",";
   atractorsFile << "\"FBP1\",";
   atractorsFile << "\"GAL1\",";
   atractorsFile << "\"GAL10\",";
   atractorsFile << "\"GAL11\",";
   atractorsFile << "\"GAL2\",";
   atractorsFile << "\"GAL3\",";
   atractorsFile << "\"GAL4\",";
   atractorsFile << "\"GAL5\",";
   atractorsFile << "\"GAL7\",";
   atractorsFile << "\"GAL80\",";
   atractorsFile << "\"GLC7\",";
   atractorsFile << "\"GRR1\",";
   atractorsFile << "\"Gal11p\",";
   atractorsFile << "\"Gal1p\",";
   atractorsFile << "\"Gal2p\",";
   atractorsFile << "\"Gal3p\",";
   atractorsFile << "\"Gal4p\",";
   atractorsFile << "\"Gal80p\",";
   atractorsFile << "\"Glc7Reg1\",";
   atractorsFile << "\"HXT1\",";
   atractorsFile << "\"HXT2\",";
   atractorsFile << "\"HXT3\",";
   atractorsFile << "\"HXT4\",";
   atractorsFile << "\"HXT5\",";
   atractorsFile << "\"HXT8\",";
   atractorsFile << "\"ICL1\",";
   atractorsFile << "\"IDP2\",";
   atractorsFile << "\"JEN1\",";
   atractorsFile << "\"MALR\",";
   atractorsFile << "\"MALS\",";
   atractorsFile << "\"MALT\",";
   atractorsFile << "\"MDH2\",";
   atractorsFile << "\"MEL1\",";
   atractorsFile << "\"MIG1\",";
   atractorsFile << "\"MIG2\",";
   atractorsFile << "\"MIG3\",";
   atractorsFile << "\"MLS1\",";
   atractorsFile << "\"MTH1\",";
   atractorsFile << "\"MalRp\",";
   atractorsFile << "\"MalTp\",";
   atractorsFile << "\"Mig1p\",";
   atractorsFile << "\"Mig2p\",";
   atractorsFile << "\"Mig3p\",";
   atractorsFile << "\"Mth1p\",";
   atractorsFile << "\"PCK1\",";
   atractorsFile << "\"REG1\",";
   atractorsFile << "\"RGT1\",";
   atractorsFile << "\"RGT2\",";
   atractorsFile << "\"Rgt1p\",";
   atractorsFile << "\"Rgt2p\",";
   atractorsFile << "\"SCF_grr1\",";
   atractorsFile << "\"SFC1\",";
   atractorsFile << "\"SIP4\",";
   atractorsFile << "\"SNF1\",";
   atractorsFile << "\"SNF3\",";
   atractorsFile << "\"SNF4\",";
   atractorsFile << "\"STD1\",";
   atractorsFile << "\"SUC2\",";
   atractorsFile << "\"Sip4p\",";
   atractorsFile << "\"Snf1p\",";
   atractorsFile << "\"Snf3p\",";
   atractorsFile << "\"Std1p\",";
   atractorsFile << "\"YCK1_2\",";
   atractorsFile << "\"Yck1p\",";
   atractorsFile << "\"galactose_ext\",";
   atractorsFile << "\"galactose_int\",";
   atractorsFile << "\"glucose_ext\",";
   atractorsFile << "\"maltose_ext\",";
   atractorsFile << "\"maltose_int73\"],\n";
   atractorsFile << "\"atractors\" : [";
   for (unsigned long long i = 0; i < atractors.size()-1; i++)
       atractorsFile << atractors[i] <<",";
   atractorsFile << atractors[atractors.size()-1] <<"]\n";
   atractorsFile << "}\n";
   atractorsFile.close();}
void init_rand_h(unsigned long long * state, unsigned long long SIMULATIONS) {
   std::random_device rd;
   std::mt19937_64 e2(rd());
   std::uniform_int_distribution<unsigned long long> dist(0, (unsigned long long)std::llround(std::pow(2,64)));
   for (unsigned long long i = 0; i < SIMULATIONS; i++) {
       for (size_t j = 0; j < 2; j++)
           state[i*2 + j] = dist(e2);
   }
}
int main(int argc, char **argv) {
   unsigned long long SIMULATIONS = 0;
   std::string argv2 = argv[1];
   for(int i = 0; i < argv2.size() ; i++)
       SIMULATIONS += ((unsigned long long)(argv2[i] - '0'))*pow(10,argv2.size()-i-1);
   cout << "Alocating memory...";
   unsigned long long * statef_h, * statef_d;
   statef_h = new unsigned long long[SIMULATIONS*2];
   cout << "[OK]" << '\n';
   cout << "Initiating values...";
   init_rand_h(statef_h, SIMULATIONS);
   cout << "[OK]" << '\n';
   auto start_cpu = high_resolution_clock::now();
   network_simulation_h(statef_h, SIMULATIONS);
   auto end_cpu = high_resolution_clock::now();
   auto dt_cpu = duration<double, milli> (end_cpu - start_cpu);
   cout << "Running Time CPU (ms) : " << dt_cpu.count() << '\n';
   cout << "Getting atractors found...";
   vector<string> atratores = complete_atractors(statef_h, SIMULATIONS);
   cout << "[OK]" << '\n';
   output_atractors(atratores);
   delete [] statef_h;
   return 0;
}
