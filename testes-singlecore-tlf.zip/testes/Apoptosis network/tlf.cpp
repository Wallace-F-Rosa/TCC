#include <iostream>
#include <chrono>
#include <ctime>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include <map>
#include <unordered_map>
#include <limits>
#include <stdio.h>
#include <stdlib.h>
#include <algorithm>
#include <random>
#include <cmath>
#include <omp.h>

using namespace std;
using namespace std::chrono;

typedef unsigned long long * state;
bool equals_h(unsigned long long * a, unsigned long long * b) {
   for (int i = 0; i < 1; i++) {
       if (a[i] != b[i])
           return false;
   }
   return true;
}
void next_h(unsigned long long * s) {
   unsigned long long aux[1];
   aux[0] = 0;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 26) % 2 ) * 2 ) >= 2 ) << 0;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 30) % 2 ) * 2 ) >= 2 ) << 1;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 13) % 2 ) * 2 + ( ( s[0] >> 3) % 2 ) * 2 + ( ( s[0] >> 25) % 2 ) * 2 + ( ( s[0] >> 18) % 2 ) * -2 ) >= 6 ) << 2;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 40) % 2 ) * 2 ) >= 2 ) << 3;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 40) % 2 ) * 2 + ( ( s[0] >> 1) % 2 ) * -2 ) >= 2 ) << 4;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 21) % 2 ) * 2 + ( ( s[0] >> 40) % 2 ) * 6 + ( ( s[0] >> 6) % 2 ) * -6 + ( ( s[0] >> 12) % 2 ) * 2 ) >= 8 ) << 5;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 26) % 2 ) * 2 + ( ( s[0] >> 4) % 2 ) * -2 + ( ( s[0] >> 40) % 2 ) * -2 ) >= 2 ) << 6;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 11) % 2 ) * 2 ) >= 2 ) << 7;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 2) % 2 ) * 2 + ( ( s[0] >> 18) % 2 ) * -6 + ( ( s[0] >> 12) % 2 ) * 2 + ( ( s[0] >> 10) % 2 ) * 10 ) >= 2 ) << 8;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 8) % 2 ) * 2 ) >= 2 ) << 9;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 8) % 2 ) * 2 + ( ( s[0] >> 18) % 2 ) * -2 ) >= 2 ) << 10;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 2) % 2 ) * 2 + ( ( s[0] >> 18) % 2 ) * -6 + ( ( s[0] >> 12) % 2 ) * 2 ) >= 2 ) << 11;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 10) % 2 ) * 2 + ( ( s[0] >> 39) % 2 ) * -6 + ( ( s[0] >> 15) % 2 ) * 2 ) >= 2 ) << 12;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 8) % 2 ) * 2 + ( ( s[0] >> 1) % 2 ) * -6 + ( ( s[0] >> 18) % 2 ) * -6 + ( ( s[0] >> 7) % 2 ) * 2 ) >= 2 ) << 13;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 9) % 2 ) * 2 + ( ( s[0] >> 8) % 2 ) * 2 ) >= 4 ) << 14;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 36) % 2 ) * 2 ) >= 2 ) << 15;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 16) % 2 ) * 2 ) >= 2 ) << 16;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 16) % 2 ) * 2 ) >= 2 ) << 17;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 26) % 2 ) * 6 + ( ( s[0] >> 25) % 2 ) * -6 + ( ( s[0] >> 8) % 2 ) * -2 + ( ( s[0] >> 10) % 2 ) * -2 ) >= 4 ) << 18;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 1) % 2 ) * 2 + ( ( s[0] >> 0) % 2 ) * -6 + ( ( s[0] >> 27) % 2 ) * 2 ) >= 2 ) << 19;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 26) % 2 ) * 2 + ( ( s[0] >> 19) % 2 ) * -2 ) >= 2 ) << 20;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 22) % 2 ) * 2 ) >= 2 ) << 21;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 23) % 2 ) * 2 + ( ( s[0] >> 1) % 2 ) * -2 ) >= 2 ) << 22;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 37) % 2 ) * 2 ) >= 2 ) << 23;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 1) % 2 ) * 2 + ( ( s[0] >> 40) % 2 ) * 2 ) >= 2 ) << 24;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 5) % 2 ) * 2 + ( ( s[0] >> 6) % 2 ) * -2 ) >= 2 ) << 25;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 20) % 2 ) * -2 ) >= 0 ) << 26;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 38) % 2 ) * 2 ) >= 2 ) << 27;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 17) % 2 ) * 2 ) >= 2 ) << 28;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 17) % 2 ) * 2 ) >= 2 ) << 29;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 28) % 2 ) * 2 + ( ( s[0] >> 29) % 2 ) * 2 + ( ( s[0] >> 31) % 2 ) * -2 ) >= 4 ) << 30;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 40) % 2 ) * 2 ) >= 2 ) << 31;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 36) % 2 ) * 2 ) >= 2 ) << 32;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 33) % 2 ) * 2 ) >= 2 ) << 33;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 33) % 2 ) * 2 ) >= 2 ) << 34;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 33) % 2 ) * 2 ) >= 2 ) << 35;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 34) % 2 ) * 2 ) >= 2 ) << 36;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 36) % 2 ) * 2 ) >= 2 ) << 37;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 32) % 2 ) * 2 ) >= 2 ) << 38;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 37) % 2 ) * 2 ) >= 2 ) << 39;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 21) % 2 ) * 2 + ( ( s[0] >> 24) % 2 ) * -6 + ( ( s[0] >> 14) % 2 ) * 2 ) >= 2 ) << 40;
   s[0] = aux[0];
}

void network_simulation_h(unsigned long long * statef, unsigned long long SIMULATIONS){
   unsigned long long i;
   for(i = 0; i < SIMULATIONS; i++){
       unsigned long long state0[1], state1[1], aux[1];
       state0[0] = state1[0] = statef[i*1 + 0];
       do {
           next_h(state0);
           next_h(state1);
           next_h(state1);
       } while(!equals_h(state0, state1));
       statef[i*1 + 0] = state1[0];
   }
}
string to_string(unsigned long long * s){
   string result;
   stringstream stream;
   for(int i = 0; i >= 0; i--)
       stream << s[i];
   stream >> result;
   return result;
}
string to_string(vector<string> atractor){
   if(atractor.size() == 0) return "['']";
   string result = "[" + atractor[0];
   for (int i = 1; i < atractor.size(); i++)
       result += "," + atractor[i];
   result += "]";
   return result;
}
vector<string> getAtractor(unsigned long long * s) {
   unsigned long long s0[1], s1[1], aux[1];
   vector<string> atractor; atractor.push_back(to_string(s));
   for (int i = 0; i < 1; i++){
       s0[i] = s1[i] = s[i];
       aux[i] = 0;
   }
   while(true) {
       next_h(s0);
       if (!equals_h(s0,s1))
           atractor.push_back(to_string(s1));
       else
           break;
   }
   sort(atractor.begin(), atractor.end());
   return atractor;
}
vector<string> complete_atractors(unsigned long long * state_f, unsigned long long SIMULATIONS){
   vector<string> atractors;
   unordered_map<string, string> state_to_at;
   unordered_map<string, unsigned long> at_freq;
   for(unsigned long long i = 0; i < SIMULATIONS; i++) {
       unsigned long long st[1];
       for (size_t j = 0; j < 1; j++) {
           st[j] = state_f[i*1 + j];
       }
       string sst = to_string(st);
       if (state_to_at.count(sst) > 0) {
           at_freq[state_to_at[sst]]++;
       } else {
           vector<string> at = getAtractor(st);
           string sat = to_string(at);
           atractors.push_back(sat);
           for (int j = 0; j < at.size(); j++)
               state_to_at[at[j]] = sat;
           at_freq[sat]=1;
       }
   }
   return atractors;
}
void output_atractors(const vector<string> &atractors) {
   ofstream atractorsFile;
   atractorsFile.open("atractors.json");
   atractorsFile << "{\n";
   atractorsFile << "\"nodes\" : [";
   atractorsFile << "\"A20\",";
   atractorsFile << "\"AKT\",";
   atractorsFile << "\"APC\",";
   atractorsFile << "\"Apaf1\",";
   atractorsFile << "\"BAD\",";
   atractorsFile << "\"BID\",";
   atractorsFile << "\"BclX\",";
   atractorsFile << "\"Cas12\",";
   atractorsFile << "\"Cas3\",";
   atractorsFile << "\"Cas3_dummy\",";
   atractorsFile << "\"Cas6\",";
   atractorsFile << "\"Cas7\",";
   atractorsFile << "\"Cas8\",";
   atractorsFile << "\"Cas9\",";
   atractorsFile << "\"DNADamageEvent\",";
   atractorsFile << "\"FADD\",";
   atractorsFile << "\"GF\",";
   atractorsFile << "\"GFR\",";
   atractorsFile << "\"IAP\",";
   atractorsFile << "\"IKK\",";
   atractorsFile << "\"IkB\",";
   atractorsFile << "\"JNK\",";
   atractorsFile << "\"JNKK\",";
   atractorsFile << "\"MEKK1\",";
   atractorsFile << "\"Mdm2\",";
   atractorsFile << "\"Mito\",";
   atractorsFile << "\"NFkB\",";
   atractorsFile << "\"NIK\",";
   atractorsFile << "\"PI3K\",";
   atractorsFile << "\"PIP2\",";
   atractorsFile << "\"PIP3\",";
   atractorsFile << "\"PTEN\",";
   atractorsFile << "\"RIP\",";
   atractorsFile << "\"TNF\",";
   atractorsFile << "\"TNFR1\",";
   atractorsFile << "\"TNFR2\",";
   atractorsFile << "\"TRADD\",";
   atractorsFile << "\"TRAF\",";
   atractorsFile << "\"TRAF2\",";
   atractorsFile << "\"cFLIP\",";
   atractorsFile << "\"p5341\"],\n";
   atractorsFile << "\"atractors\" : [";
   for (unsigned long long i = 0; i < atractors.size()-1; i++)
       atractorsFile << atractors[i] <<",";
   atractorsFile << atractors[atractors.size()-1] <<"]\n";
   atractorsFile << "}\n";
   atractorsFile.close();}
void init_rand_h(unsigned long long * state, unsigned long long SIMULATIONS) {
   std::random_device rd;
   std::mt19937_64 e2(rd());
   std::uniform_int_distribution<unsigned long long> dist(0, (unsigned long long)std::llround(std::pow(2,64)));
   for (unsigned long long i = 0; i < SIMULATIONS; i++) {
       for (size_t j = 0; j < 1; j++)
           state[i*1 + j] = dist(e2);
   }
}
int main(int argc, char **argv) {
   unsigned long long SIMULATIONS = 0;
   std::string argv2 = argv[1];
   for(int i = 0; i < argv2.size() ; i++)
       SIMULATIONS += ((unsigned long long)(argv2[i] - '0'))*pow(10,argv2.size()-i-1);
   cout << "Alocating memory...";
   unsigned long long * statef_h, * statef_d;
   statef_h = new unsigned long long[SIMULATIONS*1];
   cout << "[OK]" << '\n';
   cout << "Initiating values...";
   init_rand_h(statef_h, SIMULATIONS);
   cout << "[OK]" << '\n';
   auto start_cpu = high_resolution_clock::now();
   network_simulation_h(statef_h, SIMULATIONS);
   auto end_cpu = high_resolution_clock::now();
   auto dt_cpu = duration<double, milli> (end_cpu - start_cpu);
   cout << "Running Time CPU (ms) : " << dt_cpu.count() << '\n';
   cout << "Getting atractors found...";
   vector<string> atratores = complete_atractors(statef_h, SIMULATIONS);
   cout << "[OK]" << '\n';
   output_atractors(atratores);
   delete [] statef_h;
   return 0;
}
