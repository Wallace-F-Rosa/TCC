#include <iostream>
#include <chrono>
#include <ctime>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include <map>
#include <unordered_map>
#include <limits>
#include <stdio.h>
#include <stdlib.h>
#include <algorithm>
#include <random>
#include <cmath>
#include <omp.h>

using namespace std;
using namespace std::chrono;

typedef unsigned long long * state;
bool equals_h(unsigned long long * a, unsigned long long * b) {
   for (int i = 0; i < 2; i++) {
       if (a[i] != b[i])
           return false;
   }
   return true;
}
void next_h(unsigned long long * s) {
   unsigned long long aux[2];
   aux[0] = 0;
   aux[1] = 0;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 0;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 )  &&  ( ( ( ( ( s[0] >> 0) % 2 ) ) ) ) )  ||  ( ( ( s[0] >> 0) % 2 ) )  ) << 1;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 2;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 3;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 )  &&  ( ( ( ( ( s[1] >> 1) % 2 ) ) ) ) )  ) << 4;
    aux[0] |= (unsigned long long) ( ( ( ( ( s[0] >> 0) % 2 )  &&  ( ( ( ( ( s[0] >> 0) % 2 ) ) ) ) )  &&  ! ( ( ( s[1] >> 1) % 2 ) ) )  ) << 5;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 6;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 7;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 8;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 9;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 10;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 11;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ||  ( ( ( s[0] >> 0) % 2 ) )  ) << 12;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 )  &&  ( ( ( ( ( s[0] >> 0) % 2 ) ) ) ) )  ||  ( ( ( s[0] >> 0) % 2 ) )  ) << 13;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 14;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ||  ( ( ( s[0] >> 0) % 2 ) )  ) << 15;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 16;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 17;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 18;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 19;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 20;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 21;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ||  ( ( ( s[0] >> 0) % 2 ) )  ||  ( ( ( s[0] >> 0) % 2 ) )  ) << 22;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 23;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 )  &&  ( ( ( ( ( s[0] >> 0) % 2 )  &&  ( ( s[0] >> 0) % 2 ) ) ) ) )  ) << 24;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ||  ( ( ( s[0] >> 0) % 2 ) )  ) << 25;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 26;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 27;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 28;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ||  ( ( ( s[0] >> 0) % 2 ) )  ||  ( ( ( s[0] >> 0) % 2 ) )  ) << 29;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 30;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 31;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ||  ( ( ( s[0] >> 0) % 2 ) )  ) << 32;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ||  ( ( ( s[0] >> 0) % 2 ) )  ) << 33;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 )  &&  ( ( ( ( ( s[0] >> 0) % 2 )  &&  ( ( s[0] >> 0) % 2 )  &&  ( ( s[0] >> 0) % 2 ) ) ) ) )  ) << 34;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ||  ( ( ( s[0] >> 0) % 2 ) )  ) << 35;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 )  &&  ( ( ( ( ( s[0] >> 0) % 2 ) ) ) ) )  ) << 36;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 37;
    aux[0] |= (unsigned long long) ( ( ( ( ( s[0] >> 0) % 2 ) )  &&  ! ( ( ( s[0] >> 0) % 2 ) ) )  ) << 38;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 39;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 )  &&  ( ( ( ( ( s[0] >> 0) % 2 ) ) ) ) )  ) << 40;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 41;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 42;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ||  ( ( ( s[0] >> 0) % 2 ) )  ) << 43;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 )  &&  ( ( ( ( ( s[0] >> 0) % 2 ) ) ) ) )  ) << 44;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 45;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 46;
    aux[0] |= (unsigned long long) ( ( ( ( ( s[0] >> 0) % 2 )  &&  ( ( ( ( ( s[0] >> 0) % 2 ) ) ) ) )  &&  ! ( ( ( s[1] >> 1) % 2 ) ) )  ||  ( ( ( s[0] >> 0) % 2 ) )  ) << 47;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 48;
    aux[0] |= (unsigned long long) ( ( ( ( ( s[0] >> 0) % 2 )  &&  ( ( ( ( ( s[0] >> 0) % 2 ) ) ) ) )  &&  ! ( ( ( s[0] >> 0) % 2 ) ) )  ) << 49;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 )  &&  ( ( ( ! ( ( s[0] >> 0) % 2 ) ) )  ||  ( ( ! ( ( s[0] >> 0) % 2 ) ) ) ) )  ) << 50;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ||  ( ( ( s[0] >> 0) % 2 ) )  ) << 51;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 52;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 )  &&  ( ( ( ( ( s[0] >> 0) % 2 )  &&  ( ( s[0] >> 0) % 2 ) ) ) ) )  ) << 53;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 )  &&  ( ( ( ( ( s[0] >> 0) % 2 ) ) ) ) )  ) << 54;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 55;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 56;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 57;
    aux[0] |= (unsigned long long) ( ( ( ( s[1] >> 1) % 2 ) )  ) << 58;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ||  ( ( ( s[0] >> 0) % 2 ) )  ) << 59;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 ) )  ) << 60;
    aux[0] |= (unsigned long long) ( ( ( ( s[0] >> 0) % 2 )  &&  ( ( ( ( ( s[0] >> 0) % 2 ) ) ) ) )  ||  ( ( ( s[0] >> 0) % 2 ) )  ) << 61;
    aux[0] |= (unsigned long long) ( ( ( s[0] >> 0) % 2 )  ) << 62;
    aux[0] |= (unsigned long long) ( ( ( s[0] >> 0) % 2 )  ) << 63;
    aux[1] |= (unsigned long long) ( ( ( s[1] >> 1) % 2 )  ) << 0;
    aux[1] |= (unsigned long long) ( ( ( s[1] >> 1) % 2 )  ) << 1;
    aux[1] |= (unsigned long long) ( ( ( s[1] >> 1) % 2 )  ) << 2;
    aux[1] |= (unsigned long long) ( ( ( s[1] >> 1) % 2 )  ) << 3;
   s[0] = aux[0];
   s[1] = aux[1];
}

void network_simulation_h(unsigned long long * statef, unsigned long long SIMULATIONS){
   unsigned long long i;
   for(i = 0; i < SIMULATIONS; i++){
       unsigned long long state0[2], state1[2], aux[2];
       state0[0] = state1[0] = statef[i*2 + 0];
       state0[1] = state1[1] = statef[i*2 + 1];
       do {
           next_h(state0);
           next_h(state1);
           next_h(state1);
       } while(!equals_h(state0, state1));
       statef[i*2 + 0] = state1[0];
       statef[i*2 + 1] = state1[1];
   }
}
string to_string(unsigned long long * s){
   string result;
   stringstream stream;
   for(int i = 1; i >= 0; i--)
       stream << s[i];
   stream >> result;
   return result;
}
string to_string(vector<string> atractor){
   if(atractor.size() == 0) return "['']";
   string result = "[" + atractor[0];
   for (int i = 1; i < atractor.size(); i++)
       result += "," + atractor[i];
   result += "]";
   return result;
}
vector<string> getAtractor(unsigned long long * s) {
   unsigned long long s0[2], s1[2], aux[2];
   vector<string> atractor; atractor.push_back(to_string(s));
   for (int i = 0; i < 2; i++){
       s0[i] = s1[i] = s[i];
       aux[i] = 0;
   }
   while(true) {
       next_h(s0);
       if (!equals_h(s0,s1))
           atractor.push_back(to_string(s1));
       else
           break;
   }
   sort(atractor.begin(), atractor.end());
   return atractor;
}
vector<string> complete_atractors(unsigned long long * state_f, unsigned long long SIMULATIONS){
   vector<string> atractors;
   unordered_map<string, string> state_to_at;
   unordered_map<string, unsigned long> at_freq;
   for(unsigned long long i = 0; i < SIMULATIONS; i++) {
       unsigned long long st[2];
       for (size_t j = 0; j < 2; j++) {
           st[j] = state_f[i*2 + j];
       }
       string sst = to_string(st);
       if (state_to_at.count(sst) > 0) {
           at_freq[state_to_at[sst]]++;
       } else {
           vector<string> at = getAtractor(st);
           string sat = to_string(at);
           atractors.push_back(sat);
           for (int j = 0; j < at.size(); j++)
               state_to_at[at[j]] = sat;
           at_freq[sat]=1;
       }
   }
   return atractors;
}
void output_atractors(const vector<string> &atractors) {
   ofstream atractorsFile;
   atractorsFile.open("atractors.json");
   atractorsFile << "{\n";
   atractorsFile << "\"nodes\" : [";
   atractorsFile << "\"Mekk4\",";
   atractorsFile << "\"PTGS2\",";
   atractorsFile << "\"CDKN1A\",";
   atractorsFile << "\"DAG\",";
   atractorsFile << "\"Plasmin\",";
   atractorsFile << "\"PKC\",";
   atractorsFile << "\"PAK3\",";
   atractorsFile << "\"IP3\",";
   atractorsFile << "\"Mkk3\",";
   atractorsFile << "\"SOS\",";
   atractorsFile << "\"ECM\",";
   atractorsFile << "\"Grb2\",";
   atractorsFile << "\"PLC_g\",";
   atractorsFile << "\"PI3K\",";
   atractorsFile << "\"Erk\",";
   atractorsFile << "\"CyclinD\",";
   atractorsFile << "\"Mekk1\",";
   atractorsFile << "\"CCL20\",";
   atractorsFile << "\"Ras\",";
   atractorsFile << "\"Ca\",";
   atractorsFile << "\"C3G\",";
   atractorsFile << "\"PAK2\",";
   atractorsFile << "\"Shc\",";
   atractorsFile << "\"uPA\",";
   atractorsFile << "\"Raf\",";
   atractorsFile << "\"Mek\",";
   atractorsFile << "\"CRKL\",";
   atractorsFile << "\"uPAR\",";
   atractorsFile << "\"cMYC\",";
   atractorsFile << "\"Mkk4\",";
   atractorsFile << "\"EGR1\",";
   atractorsFile << "\"cFOS\",";
   atractorsFile << "\"IL8\",";
   atractorsFile << "\"CTGF\",";
   atractorsFile << "\"CellMigration\",";
   atractorsFile << "\"EGFR\",";
   atractorsFile << "\"cJUN\",";
   atractorsFile << "\"MMP1_10\",";
   atractorsFile << "\"Akt\",";
   atractorsFile << "\"DOCK180\",";
   atractorsFile << "\"AP1\",";
   atractorsFile << "\"MLK3\",";
   atractorsFile << "\"Integrins\",";
   atractorsFile << "\"CDKN2A\",";
   atractorsFile << "\"ATF2\",";
   atractorsFile << "\"RSK\",";
   atractorsFile << "\"ETS\",";
   atractorsFile << "\"p38\",";
   atractorsFile << "\"Mkk6\",";
   atractorsFile << "\"Fak\",";
   atractorsFile << "\"CDK2\",";
   atractorsFile << "\"Elk1\",";
   atractorsFile << "\"Rap1\",";
   atractorsFile << "\"Cdc42_Rac1\",";
   atractorsFile << "\"Proliferation\",";
   atractorsFile << "\"PAK1\",";
   atractorsFile << "\"STAT3\",";
   atractorsFile << "\"CREB\",";
   atractorsFile << "\"MET\",";
   atractorsFile << "\"HBEGF\",";
   atractorsFile << "\"Mekk7\",";
   atractorsFile << "\"JNK\",";
   atractorsFile << "\"PTEN\",";
   atractorsFile << "\"EGF\",";
   atractorsFile << "\"HGF\",";
   atractorsFile << "\"AKAP12\",";
   atractorsFile << "\"PAI-1\",";
   atractorsFile << "\"DUSP1\"],\n";
   atractorsFile << "\"atractors\" : [";
   for (unsigned long long i = 0; i < atractors.size()-1; i++)
       atractorsFile << atractors[i] <<",";
   atractorsFile << atractors[atractors.size()-1] <<"]\n";
   atractorsFile << "}\n";
   atractorsFile.close();}
void init_rand_h(unsigned long long * state, unsigned long long SIMULATIONS) {
   std::random_device rd;
   std::mt19937_64 e2(rd());
   std::uniform_int_distribution<unsigned long long> dist(0, (unsigned long long)std::llround(std::pow(2,64)));
   for (unsigned long long i = 0; i < SIMULATIONS; i++) {
       for (size_t j = 0; j < 2; j++)
           state[i*2 + j] = dist(e2);
   }
}
int main(int argc, char **argv) {
   unsigned long long SIMULATIONS = 0;
   std::string argv2 = argv[1];
   for(int i = 0; i < argv2.size() ; i++)
       SIMULATIONS += ((unsigned long long)(argv2[i] - '0'))*pow(10,argv2.size()-i-1);
   cout << "Alocating memory...";
   unsigned long long * statef_h, * statef_d;
   statef_h = new unsigned long long[SIMULATIONS*2];
   cout << "[OK]" << '\n';
   cout << "Initiating values...";
   init_rand_h(statef_h, SIMULATIONS);
   cout << "[OK]" << '\n';
   auto start_cpu = high_resolution_clock::now();
   network_simulation_h(statef_h, SIMULATIONS);
   auto end_cpu = high_resolution_clock::now();
   auto dt_cpu = duration<double, milli> (end_cpu - start_cpu);
   cout << "Running Time CPU (ms) : " << dt_cpu.count() << '\n';
   cout << "Getting atractors found...";
   vector<string> atratores = complete_atractors(statef_h, SIMULATIONS);
   cout << "[OK]" << '\n';
   output_atractors(atratores);
   delete [] statef_h;
   return 0;
}
